# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from __future__ import absolute_import, division, print_function

from stripe.stripe_object import StripeObject


class LineItem(StripeObject):
    """
    A line item.
    """

    OBJECT_NAME = "item"
