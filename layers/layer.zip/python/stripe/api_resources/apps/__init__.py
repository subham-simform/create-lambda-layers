# -*- coding: utf-8 -*-
# File generated from our OpenAPI spec
from __future__ import absolute_import, division, print_function

# flake8: noqa

from stripe.api_resources.apps.secret import Secret
